#!/usr/bin/env python3
"""Arena Live IndexNow pinger (local, hourly).
Detects NEW match pages via sitemap vs local cache; pings each new URL once.
Replaces unreliable worker->indexnow fetch (Bing rate-limits CF egress IPs).
"""
import json, re, time, urllib.request, urllib.parse, pathlib

KEY = 'e4fef50b8047068fc6967d16570e89a2'
BASE = 'https://arenalive.ir'
CACHE = pathlib.Path(__file__).parent / 'cache.json'
LOG = pathlib.Path(__file__).parent / 'pinger.log'

def log(msg):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n"
    LOG.open('a').write(line)

def fetch_sitemap():
    req = urllib.request.Request(BASE + '/sitemap.xml', headers={'User-Agent': 'Mozilla/5.0'})
    data = urllib.request.urlopen(req, timeout=60).read().decode('utf-8', 'ignore')
    return re.findall(r'<loc>([^<]+)</loc>', data)

def ping(url):
    qs = urllib.parse.urlencode({'url': url, 'key': KEY, 'keyLocation': f'{BASE}/{KEY}.txt'})
    req = urllib.request.Request(f'https://api.indexnow.org/indexnow?{qs}',
                                 headers={'User-Agent': 'Mozilla/5.0'})
    try:
        r = urllib.request.urlopen(req, timeout=20)
        return r.status
    except Exception as e:
        return getattr(e, 'code', 0)

def main():
    cache = {}
    if CACHE.exists():
        cache = json.loads(CACHE.read_text())
    urls = [u for u in fetch_sitemap() if '/matches/' in u]
    new = [u for u in urls if u not in cache]
    log(f'sitemap match pages: {len(urls)} | new: {len(new)}')
    ok = fail = 0
    for u in new[:40]:  # cap per run: polite
        st = ping(u)
        time.sleep(2)
        if 200 <= st < 300:
            cache[u] = time.time(); ok += 1
        else:
            fail += 1
            log(f'  ping {st} {u}')
    CACHE.write_text(json.dumps(cache))
    log(f'pinged {ok} ok, {fail} failed')

if __name__ == '__main__':
    main()
